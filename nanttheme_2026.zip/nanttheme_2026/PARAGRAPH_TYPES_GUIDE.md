# Complete Paragraph Types Configuration Guide

This guide covers all paragraph types in the NantTheme 2026 theme, including field configurations, setup instructions, and usage details.

---

## Table of Contents

1. [Overview](#overview)
2. [Setup Instructions](#setup-instructions)
3. [Existing Paragraph Types](#existing-paragraph-types)
4. [New Component Paragraph Types](#new-component-paragraph-types)
5. [Field Configuration Reference](#field-configuration-reference)
6. [Templates & Styling](#templates--styling)
7. [Troubleshooting](#troubleshooting)

---

## Overview

This theme includes two sets of paragraph types:

1. **Existing Paragraph Types** (6 types) - Already in use, with templates and styling provided
   - Accordion
   - Announcement
   - Blurb
   - Button
   - Image
   - List

2. **New Component Paragraph Types** (4 types) - From indexExample.html design
   - Header Component
   - Hero Component
   - Section Component
   - Footer Component

All components follow the theme's design system and use CSS custom properties for consistent styling.

---

## Setup Instructions

### Step 1: Install Dependencies

```bash
drush en paragraphs paragraphs_library -y
```

### Step 2: Create Paragraph Types

Navigate to: **Structure > Paragraph types**

Create each paragraph type using the exact machine names listed in the sections below.

### Step 3: Add Fields

For each paragraph type:

1. Go to **Structure > Paragraph types > [Paragraph Type] > Manage fields**
2. Add fields using the exact machine names from the tables below
3. **Important:** Create separate field instances for each paragraph type, even if they share the same field name (e.g., `field_title`). Each paragraph type needs its own field configuration.
4. Configure field settings:
   - **Image fields**: Enable alt text (required), optional title text
   - **Link fields**: Allow both internal and external URLs
   - **Text fields**: Configure max length as needed
   - **List fields**: Add options in format `key|Label` (e.g., `primary|Primary Button`)
   - **List fields**: Use the exact allowed values listed in the tables below (labels can be customized, keys must match)
   - **Entity Reference fields**: Set target type to Paragraph, select allowed types

**📖 See [FIELD_REUSE_GUIDE.md](FIELD_REUSE_GUIDE.md) for detailed explanation about field reuse.**

**⚠️ Getting "Machine name already in use" error? See [FIELD_ERROR_SOLUTION.md](FIELD_ERROR_SOLUTION.md) for step-by-step solution.**

### Step 4: Configure Field Displays

1. Go to **Structure > Paragraph types > [Paragraph Type] > Manage display**
2. Set all fields to **Hidden** (fields are rendered via Twig templates)

### Step 5: Add Paragraph Field to Content Type

1. Create or edit a Content Type
2. Add field:
   - **Field Type**: Entity reference revisions (Paragraphs)
   - **Label**: "Page Components" or "Content Sections"
   - **Machine Name**: `field_paragraphs`
   - **Allowed number of values**: Unlimited
   - **Allowed paragraph types**: Select all paragraph types you created
   - **Mode**: Closed
3. Configure display:
   - Format: Rendered entity
   - View mode: Default

### Step 6: Clear Cache

```bash
drush cache:rebuild
```

Or via UI: **Configuration > Performance > Clear all caches**

---

## Existing Paragraph Types

### 1. Accordion
**Machine Name:** `accordion`

**Important:** Use the correct spelling `accordion` (not `accordian`) to match the template naming convention.

| Field Label | Machine Name | Field Type | Required | Cardinality | Description |
|-------------|--------------|------------|----------|-------------|-------------|
| Title | `field_title` | Text (Plain) | No | 1 | Optional accordion section title |
| Item Title | `field_item_title` | Text (Plain) | Yes | Unlimited | One title per accordion item (match order with item content) |
| Item Content | `field_item_content` | Text (Long) | Yes | Unlimited | One content value per accordion item (match order with item title) |

**Notes:**
- Use multi-value fields for both item title and item content.
- Keep the number and order of titles and contents in sync (title #1 pairs with content #1, etc.).

**Template:** `paragraph--accordion.html.twig`

---

### 2. Announcement
**Machine Name:** `announcement`

| Field Label | Machine Name | Field Type | Required | Cardinality | Options/Notes |
|-------------|--------------|------------|----------|-------------|---------------|
| Icon | `field_icon` | Image | No | 1 | Optional announcement icon |
| Title | `field_title` | Text (Plain) | Yes | 1 | Announcement heading |
| Message | `field_message` | Text (Long) | Yes | 1 | Main content |
| Style | `field_style` | List (Text) | No | 1 | `default|Default`<br>`info|Info`<br>`warning|Warning`<br>`success|Success`<br>`error|Error` |
| Link | `field_link` | Link | No | 1 | Optional action link |
| Dismissible | `field_dismissible` | Boolean | No | 1 | Show close button |

**Template:** `paragraph--announcement.html.twig`

---

### 3. Blurb
**Machine Name:** `blurb`

| Field Label | Machine Name | Field Type | Required | Cardinality | Options/Notes |
|-------------|--------------|------------|----------|-------------|---------------|
| Icon | `field_icon` | Image | No | 1 | Optional icon |
| Image | `field_image` | Image | No | 1 | Optional featured image |
| Title | `field_title` | Text (Plain) | Yes | 1 | Blurb heading |
| Body | `field_body` | Text (Long) | Yes | 1 | Main content |
| Alignment | `field_alignment` | List (Text) | No | 1 | `left|Left`<br>`center|Center`<br>`right|Right` |
| Link | `field_link` | Link | No | 1 | Optional CTA link |

**Template:** `paragraph--blurb.html.twig`

---

### 4. Button
**Machine Name:** `button`

| Field Label | Machine Name | Field Type | Required | Cardinality | Options/Notes |
|-------------|--------------|------------|----------|-------------|---------------|
| Link | `field_link` | Link | Yes* | 1 | Preferred: includes URL and title |
| Text | `field_text` | Text (Plain) | No* | 1 | Alternative: button text |
| URL | `field_url` | Link | No* | 1 | Alternative: button URL |
| Button Style | `field_button_style` | List (Text) | No | 1 | `primary|Primary`<br>`secondary|Secondary`<br>`outline|Outline`<br>`ghost|Ghost` |
| Button Size | `field_button_size` | List (Text) | No | 1 | `small|Small`<br>`medium|Medium`<br>`large|Large` |
| Alignment | `field_alignment` | List (Text) | No | 1 | `left|Left`<br>`center|Center`<br>`right|Right` |

*Use Link field OR both Text + URL fields

**Template:** `paragraph--button.html.twig`

---

### 5. Image
**Machine Name:** `image`

| Field Label | Machine Name | Field Type | Required | Cardinality | Options/Notes |
|-------------|--------------|------------|----------|-------------|---------------|
| Image | `field_image` | Image | Yes | 1 | Image with alt text required |
| Caption | `field_caption` | Text (Long, Plain) | No | 1 | Optional caption below image |
| Link | `field_link` | Link | No | 1 | Optional link wrapping image |
| Alignment | `field_alignment` | List (Text) | No | 1 | `left|Left`<br>`center|Center`<br>`right|Right` |

**Template:** `paragraph--image.html.twig`

---

### 6. List
**Machine Name:** `list`

| Field Label | Machine Name | Field Type | Required | Cardinality | Options/Notes |
|-------------|--------------|------------|----------|-------------|---------------|
| Title | `field_title` | Text (Plain) | No | 1 | Optional list section title |
| List Style | `field_list_style` | List (Text) | No | 1 | `checklist|Checklist`<br>`bullet|Bullet` |
| List Items | `field_list_items` | Text (Plain) | Yes | Unlimited | One list item per value |
| List Item Links | `field_list_item_links` | Link | No | Unlimited | Optional URL per item (index matches list items) |

**Notes:**
- **Checklist** style displays items with a green checkmark icon.
- **Bullet** style displays items with standard disc bullets.
- Default style is bullet when not specified.
- When `field_list_item_links` has a URL for a given index, that list item is rendered as a link.

**Template:** `paragraph--list.html.twig`

---

## New Component Paragraph Types

These paragraph types are based on the design in `indexExample.html`:

### 1. Header Component
**Machine Name:** `header_component`

| Field Label | Machine Name | Field Type | Required | Cardinality | Description |
|-------------|--------------|------------|----------|-------------|-------------|
| Logo | `field_logo` | Image | Yes | 1 | Header logo image |
| Title | `field_title` | Text (Plain) | Yes | 1 | Main header title |
| Subtitle | `field_subtitle` | Text (Plain) | No | 1 | Subtitle text |
| Tags | `field_tags` | Text (Plain) | No | Unlimited | Tags/chips (one value per tag) |
| Tag Links | `field_tag_links` | Link | No | Unlimited | Optional URL per tag (index matches tags) |

**Notes:**
- When `field_tag_links` has a URL for a given index, that tag is rendered as a link.

**Template:** `paragraph--header-component.html.twig`

---

### 2. Hero Component
**Machine Name:** `hero_component`

| Field Label | Machine Name | Field Type | Required | Cardinality | Description |
|-------------|--------------|------------|----------|-------------|-------------|
| Title | `field_title` | Text (Plain) | Yes | 1 | Hero heading |
| Description | `field_description` | Text (Long, Plain) | Yes | 1 | Hero description |
| Primary Button Text | `field_primary_button_text` | Text (Plain) | No | 1 | Primary button text |
| Primary Button URL | `field_primary_button_url` | Link | No | 1 | Primary button URL |
| Secondary Button Text | `field_secondary_button_text` | Text (Plain) | No | 1 | Secondary button text |
| Secondary Button URL | `field_secondary_button_url` | Link | No | 1 | Secondary button URL |
| Hero Image | `field_hero_image` | Image | No | 1 | Hero section image |

**Template:** `paragraph--hero-component.html.twig` (uses `components/hero-banner.html.twig`)

---

### 3. Section Component
**Machine Name:** `section_component`

| Field Label | Machine Name | Field Type | Required | Cardinality | Description |
|-------------|--------------|------------|----------|-------------|-------------|
| Section Icon | `field_section_icon` | Image | No | 1 | Section header icon |
| Section Title | `field_section_title` | Text (Plain) | Yes | 1 | Section heading |
| Section Subtitle | `field_section_subtitle` | Text (Plain) | No | 1 | Section subtitle |
| Grid Columns | `field_grid_columns` | List (Text) | No | 1 | `1|1 Column`<br>`2|2 Columns`<br>`3|3 Columns`<br>`4|4 Columns` |
| Grid Spacing | `field_grid_spacing` | List (Text) | No | 1 | `small|Small`<br>`medium|Medium`<br>`large|Large` |
| Grid Item Image | `field_grid_item_image` | Image | No | Unlimited | Card image (one per grid item) |
| Grid Item Title | `field_grid_item_title` | Text (Plain) | Yes | Unlimited | Card title |
| Grid Item Title Link | `field_grid_item_title_link` | Link | No | Unlimited | Card title link |
| Grid Item Description | `field_grid_item_description` | Text (Long, Plain) | No | Unlimited | Card description text |
| Grid Item Primary Button Text | `field_grid_item_primary_button_text` | Text (Plain) | No | Unlimited | Primary button text |
| Grid Item Primary Button URL | `field_grid_item_primary_button_url` | Link | No | Unlimited | Primary button URL |
| Grid Item Secondary Button Text | `field_grid_item_secondary_button_text` | Text (Plain) | No | Unlimited | Secondary button text |
| Grid Item Secondary Button URL | `field_grid_item_secondary_button_url` | Link | No | Unlimited | Secondary button URL |

**Notes:**
- Grid item fields are multi-value; keep the order aligned across fields.
- Each index represents one card in the grid.

**Template:** `paragraph--section-component.html.twig`

---

### 4. Footer Component
**Machine Name:** `footer_component`

| Field Label | Machine Name | Field Type | Required | Cardinality | Description |
|-------------|--------------|------------|----------|-------------|-------------|
| Footer Text | `field_footer_text` | Text (Long, Plain) | Yes | 1 | Footer copyright/text |

**Template:** `paragraph--footer-component.html.twig`

---

## Field Configuration Reference

### Field Type Guidelines

**Text Fields:**
- **Text (Plain)**: Titles, labels, short text (max 255 chars)
- **Text (Long, Plain)**: Multi-line text without HTML
- **Text (Long)**: Rich text with HTML formatting

**Image Fields:**
- Enable **Alt text** (required for accessibility)
- Enable **Title text** (optional)
- Upload location: `public://paragraphs/`
- Recommended image styles:
  - Logo: Max 280px width
  - Hero: Max 800px width
  - Icon: 112px × 112px
  - Thumbnail: 144px × 144px

**Link Fields:**
- Allow both **internal** and **external** links
- Link title: Optional
- Default link options: Uncheck all

**List (Text) Fields:**
- Widget: Select list or Radio buttons
- Format: `key|Label` (e.g., `primary|Primary Button`)
- Add all options as separate lines
- Keys are used in templates (must match exactly)
- Labels are user-facing and can be customized

### List Field Allowed Values (Quick Reference)

Use these exact keys for list fields to match CSS and Twig logic:

**Announcement `field_style`:**
`default|Default`<br>`info|Info`<br>`warning|Warning`<br>`success|Success`<br>`error|Error`

**Blurb/Image/Button `field_alignment`:**
`left|Left`<br>`center|Center`<br>`right|Right`

**List `field_list_style`:**
`checklist|Checklist`<br>`bullet|Bullet`

**Button `field_button_style`:**
`primary|Primary`<br>`secondary|Secondary`<br>`outline|Outline`<br>`ghost|Ghost`

**Button `field_button_size`:**
`small|Small`<br>`medium|Medium`<br>`large|Large`

**Section `field_grid_columns`:**
`1|1 Column`<br>`2|2 Columns`<br>`3|3 Columns`<br>`4|4 Columns`

**Section `field_grid_spacing`:**
`small|Small`<br>`medium|Medium`<br>`large|Large`

**Global Styling `field_background_color`:**
`bg-default|Default`<br>`bg-light|Light`<br>`bg-dark|Dark`<br>`bg-primary|Primary`<br>`bg-secondary|Secondary`<br>`bg-accent|Accent`<br>`bg-success|Success`<br>`bg-warning|Warning`<br>`bg-error|Error`<br>`bg-info|Info`<br>`bg-transparent|Transparent`

**Global Styling `field_border`:**
`border|Border`<br>`border-none|No Border`

**Global Styling `field_border_color`:**
`border-color-default|Default`<br>`border-color-light|Light`<br>`border-color-dark|Dark`<br>`border-color-primary|Primary`<br>`border-color-secondary|Secondary`<br>`border-color-accent|Accent`<br>`border-color-success|Success`<br>`border-color-warning|Warning`<br>`border-color-error|Error`<br>`border-color-info|Info`

**Global Styling `field_border_style`:**
`border-style-solid|Solid`<br>`border-style-dashed|Dashed`<br>`border-style-dotted|Dotted`<br>`border-style-double|Double`

**Global Styling `field_border_width`:**
`border-width-sm|Thin`<br>`border-width-md|Medium`<br>`border-width-lg|Thick`

**Global Styling `field_box_shadow`:**
`shadow-none|None`<br>`shadow-sm|Small`<br>`shadow-md|Medium`<br>`shadow-lg|Large`<br>`shadow-xl|Extra Large`

**Global Styling `field_font_size`:**
`text-sm|Small`<br>`text-base|Base`<br>`text-lg|Large`<br>`text-xl|XL`<br>`text-2xl|2XL`<br>`text-3xl|3XL`<br>`text-4xl|4XL`

**Global Styling `field_font_weight`:**
`font-weight-normal|Normal`<br>`font-weight-medium|Medium`<br>`font-weight-semibold|Semi Bold`<br>`font-weight-bold|Bold`

**Global Styling `field_font_family`:**
`font-family-base|Base`<br>`font-family-heading|Heading`<br>`font-family-monospace|Monospace`

**Entity Reference Fields:**
- Target type: Paragraph
- Select allowed paragraph types
- Mode: Closed (users can't add new types)

**Boolean Fields:**
- Widget: Checkbox
- Default: Unchecked (false)

### Global Styling Options (Add to Every Paragraph Type)

Add these optional fields to all paragraph types to control shadows, backgrounds, borders, and typography. These values map to utility classes in `css/utilities/utilities.css` and `css/base/typography.css`.

| Field Label | Machine Name | Field Type | Required | Cardinality | Options/Notes |
|-------------|--------------|------------|----------|-------------|---------------|
| Background Color | `field_background_color` | List (Text) | No | 1 | `bg-default|Default`<br>`bg-light|Light`<br>`bg-dark|Dark`<br>`bg-primary|Primary`<br>`bg-secondary|Secondary`<br>`bg-accent|Accent`<br>`bg-success|Success`<br>`bg-warning|Warning`<br>`bg-error|Error`<br>`bg-info|Info`<br>`bg-transparent|Transparent` |
| Border | `field_border` | List (Text) | No | 1 | `border|Border`<br>`border-none|No Border` |
| Border Color | `field_border_color` | List (Text) | No | 1 | `border-color-default|Default`<br>`border-color-light|Light`<br>`border-color-dark|Dark`<br>`border-color-primary|Primary`<br>`border-color-secondary|Secondary`<br>`border-color-accent|Accent`<br>`border-color-success|Success`<br>`border-color-warning|Warning`<br>`border-color-error|Error`<br>`border-color-info|Info` |
| Border Style | `field_border_style` | List (Text) | No | 1 | `border-style-solid|Solid`<br>`border-style-dashed|Dashed`<br>`border-style-dotted|Dotted`<br>`border-style-double|Double` |
| Border Width | `field_border_width` | List (Text) | No | 1 | `border-width-sm|Thin`<br>`border-width-md|Medium`<br>`border-width-lg|Thick` |
| Drop Shadow | `field_box_shadow` | List (Text) | No | 1 | `shadow-none|None`<br>`shadow-sm|Small`<br>`shadow-md|Medium`<br>`shadow-lg|Large`<br>`shadow-xl|Extra Large` |
| Font Size | `field_font_size` | List (Text) | No | 1 | `text-sm|Small`<br>`text-base|Base`<br>`text-lg|Large`<br>`text-xl|XL`<br>`text-2xl|2XL`<br>`text-3xl|3XL`<br>`text-4xl|4XL` |
| Font Weight | `field_font_weight` | List (Text) | No | 1 | `font-weight-normal|Normal`<br>`font-weight-medium|Medium`<br>`font-weight-semibold|Semi Bold`<br>`font-weight-bold|Bold` |
| Font Family | `field_font_family` | List (Text) | No | 1 | `font-family-base|Base`<br>`font-family-heading|Heading`<br>`font-family-monospace|Monospace` |

---

## Templates & Styling

### Template Locations

All paragraph templates should be in:
```
templates/paragraphs/paragraph--{machine-name}.html.twig
```

### Existing Templates

- ✅ `paragraph--accordion.html.twig`
- ✅ `paragraph--announcement.html.twig`
- ✅ `paragraph--blurb.html.twig`
- ✅ `paragraph--button.html.twig`
- ✅ `paragraph--image.html.twig`
- ✅ `paragraph--list.html.twig`
- ✅ `paragraph--header-component.html.twig`
- ✅ `paragraph--hero-component.html.twig`
- ✅ `paragraph--section-component.html.twig`
- ✅ `paragraph--footer-component.html.twig`

### CSS Files

All component CSS is in `css/components/`:
- `accordion.css`
- `announcement.css`
- `blurb.css`
- `footer-component.css`
- `header-component.css`
- `paragraph-button.css`
- `paragraph-image.css`
- `list.css`
- `card-grid.css` (for section component grid)
- `hero-banner.css` (for hero component)
- `section-component.css`

All CSS files are included in `nanttheme_2026.libraries.yml`.

### JavaScript Files

Interactive components have JavaScript:
- `js/components/accordion.js` - Expand/collapse
- `js/components/announcement.js` - Dismiss functionality

---

## Troubleshooting

### Template Not Rendering

1. **Clear cache:**
   ```bash
   drush cache:rebuild
   ```

2. **Verify machine name:**
   - Template filename must match: `paragraph--{machine-name}.html.twig`
   - Machine name is case-sensitive

3. **Check view mode:**
   - Paragraph view mode should be "Default"
   - Or match the template suggestion

4. **Verify template location:**
   - Must be in `templates/paragraphs/` directory

### Styles Not Applying

1. **Check libraries.yml:**
   - Verify CSS files are listed in global library
   - Check file paths are correct

2. **Clear cache:**
   ```bash
   drush cache:rebuild
   ```

3. **Check browser console:**
   - Look for CSS file 404 errors
   - Verify CSS syntax is correct

### JavaScript Not Working

1. **Check jQuery:**
   - jQuery must be loaded
   - Check browser console for errors

2. **Verify Drupal.behaviors:**
   - JavaScript must use Drupal.behaviors pattern
   - Theme uses `core/jquery.once` or data-based fallback for once behavior

3. **Check browser console:**
   - Look for JavaScript errors
   - Verify selectors match HTML

### Fields Not Displaying

1. **Check field machine names:**
   - Must match exactly in template
   - Case-sensitive

2. **Verify field values:**
   - Check paragraph has field values
   - Check field is not hidden in display settings

3. **Check template syntax:**
   - Verify field rendering code
   - Check for typos in field names

### Common Issues

**Issue:** Paragraph type not showing in dropdown
- **Solution:** Clear cache and check paragraph type is enabled

**Issue:** Field not saving
- **Solution:** Check field is not disabled, verify required fields are filled

**Issue:** Image not displaying
- **Solution:** Check image field has value, verify image style is configured

**Issue:** Link field not working
- **Solution:** Check URL format, verify link field allows external URLs

---

## Quick Setup Checklist

### For Each Paragraph Type:

- [ ] Create paragraph type with exact machine name
- [ ] Add all fields with exact machine names
- [ ] Configure field settings (required, cardinality, widgets)
- [ ] Configure field displays (set to Hidden)
- [ ] Create/verify template exists
- [ ] Test paragraph creation
- [ ] Test rendering on page

### Global Setup:

- [ ] Paragraphs module enabled
- [ ] Content type has paragraph field
- [ ] Paragraph field allows all paragraph types
- [ ] All CSS files in libraries.yml
- [ ] All templates in correct directory
- [ ] Cache cleared
- [ ] Tested on page

---

## Support & Resources

- **Theme Documentation:** See `README.md` for theme overview
- **Field Reuse Guide:** See `FIELD_REUSE_GUIDE.md` for explanation about creating fields for paragraph types
- **Template Examples:** Check existing templates in `templates/paragraphs/`
- **CSS Variables:** See `css/base/variables.css` for design tokens
- **Drupal Paragraphs:** https://www.drupal.org/project/paragraphs

---

## Summary

This theme includes **10 paragraph types** total:

**Existing (6):**
1. Accordion
2. Announcement
3. Blurb
4. Button
5. Image
6. List

**New Components (4):**
1. Header Component
2. Hero Component
3. Section Component
4. Footer Component

All components follow consistent field naming conventions and design system. Templates and styling are provided for all existing paragraph types and new component paragraph types.

For detailed field configurations, see the tables in the sections above. For setup instructions, follow the steps in the Setup Instructions section.
