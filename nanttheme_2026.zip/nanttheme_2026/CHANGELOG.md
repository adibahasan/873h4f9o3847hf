# Changelog

All notable changes to NantTheme 2026 will be documented in this file.

## [1.0.0] - 2026-01-XX

### Added
- Initial theme structure with Drupal 10/11 compatibility
- Component-based architecture
- Card Grid component with flexible column layouts
- Hero Banner component with image backgrounds and overlays
- Base CSS framework with CSS custom properties
- Responsive grid system
- Button component with multiple variants
- Mercury editor integration and styling
- Page layout templates (HTML, Page, Block, Region, Node)
- Utility classes for common patterns
- JavaScript enhancements for theme functionality
- Comprehensive documentation (README.md)

### Features
- Modern, accessible markup
- Mobile-first responsive design
- Performance optimizations
- Browser compatibility (Chrome, Firefox, Safari, Edge)
