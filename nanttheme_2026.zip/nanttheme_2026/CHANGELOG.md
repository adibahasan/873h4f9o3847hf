# Changelog

All notable changes to NantTheme 2026 will be documented in this file.

## [1.0.2] - 2026-02-04

### Added
- List component: Optional link per item (`field_list_item_links`)
- Header component: Optional link per tag (`field_tag_links`)
- Inter as primary font (Google Fonts)
- VERSION_LOG.md – detailed change log by component

### Changed
- Accordion: 15px padding above content
- Blurb: Left-aligned image-on-left layout; stock images; copy (icon → image)
- Buttons: Unified default size across components; small size preserved
- Card grid: Medical stock image for first card
- Image component: Medical stock image
- Typography: Inter font family

**See [VERSION_LOG.md](VERSION_LOG.md) for full details by component.**

---

## [1.0.1] - 2026-02-XX

### Changed
- Accordion: Inline items (field_item_title, field_item_content) instead of nested accordion_item paragraphs
- Section Component: Inline grid items instead of link_grid_item paragraph references
- Removed Link Grid Item paragraph type (integrated into Section Component)
- Added global styling options (background, border, shadow, font) to all paragraph types
- Added grid columns and spacing fields to Section Component
- Header logo max-width set to 250px
- Button styles: Removed unused .btn variants, kept .button only
- Typography: Removed duplicate .text-small and .text-large utilities

### Removed
- paragraph--accordion-item.html.twig
- paragraph--link-grid-item.html.twig
- ComponentIcons/link-grid-item.svg
- Unused button styles (.btn, .button--full, .button--icon, button-group)

### Fixed
- jQuery .once compatibility (use core/jquery.once or data-based fallback)
- Logo max-width override when inside .node__content
- Preprocess paragraph to hide style option fields from rendering as text

## [1.0.0] - 2026-01-XX

### Added
- Initial theme structure with Drupal 10/11 compatibility
- Component-based architecture
- Card Grid component with flexible column layouts
- Hero Banner component with image backgrounds and overlays
- Base CSS framework with CSS custom properties
- Responsive grid system
- Button component with multiple variants
- Mercury editor integration and styling
- Page layout templates (HTML, Page, Block, Region, Node)
- Utility classes for common patterns
- JavaScript enhancements for theme functionality
- Comprehensive documentation (README.md)

### Features
- Modern, accessible markup
- Mobile-first responsive design
- Performance optimizations
- Browser compatibility (Chrome, Firefox, Safari, Edge)
