# Solving "Machine Name Already in Use" Error

## Quick Solution

When you see: **"The machine-readable name is already in use. It must be unique."**

You need to **REUSE the existing field** instead of creating a new one.

---

## Solution: Use "Add Existing Field"

### Step-by-Step:

1. **Go to your paragraph type's field management:**
   ```
   Structure > Paragraph types > [Your Paragraph Type] > Manage fields
   ```

2. **Instead of clicking "Add new field", look for:**
   - **"Add existing field"** tab or button
   - Or Drupal may automatically show existing fields

3. **Select the existing field from the dropdown:**
   - Look for your field name (e.g., `field_title`)
   - Select it from the list
   - Click "Save and continue"

4. **Configure the field for THIS paragraph type:**
   - You can set different settings than the other paragraph type
   - Required/optional can differ
   - Help text can differ
   - But they share the same field storage

---

## Example Walkthrough

### Scenario: You already created `field_title` for Announcement, now need it for Blurb

**What NOT to do:**
```
❌ Click "Add new field"
❌ Select "Text (Plain)"
❌ Enter machine name: field_title
❌ ERROR: "Machine name already in use"
```

**What TO do:**
```
✅ Click "Add existing field" tab
✅ Select "field_title" from dropdown
✅ Configure settings for Blurb
✅ Save successfully
```

---

## Visual Guide

When adding fields, you'll see two options:

### Option 1: Add new field
- Creates a completely new field
- Requires unique machine name
- Use this for the FIRST time creating a field

### Option 2: Add existing field ⬅️ **Use this!**
- Reuses existing field storage
- Same machine name is OK
- Use this when field already exists

---

## Common Fields You Can Reuse

These fields likely already exist if you've created them for other paragraph types:

### Fields to Reuse (Not Create New):

| Field Name | When to Reuse |
|------------|---------------|
| `field_title` | If you created it for Announcement, reuse for Blurb, Hero, etc. |
| `field_link` | If you created it for Button, reuse for Announcement, Blurb, etc. |
| `field_image` | If you created it for Image paragraph, reuse for Blurb, etc. |
| `field_icon` | If you created it for Announcement, reuse for Blurb, etc. |
| `field_alignment` | If you created it for Blurb, reuse for Button, Image, etc. |

---

## When to Create New vs Reuse

### Create NEW field when:
- ✅ This is the FIRST paragraph type using this field
- ✅ Field has a completely unique purpose
- ✅ Field type is different from existing fields

### REUSE existing field when:
- ✅ Field already exists on another paragraph type
- ✅ Same field type (e.g., both Text Plain)
- ✅ Same basic purpose (e.g., both are titles)

---

## Troubleshooting Steps

### Step 1: Check What Fields Already Exist

1. Go to: **Structure > Configuration > Field list**
   - Or: `/admin/structure/field-list`

2. Look for your field name (e.g., `field_title`)
   - If it appears, it exists and you should REUSE it
   - If it doesn't appear, create it as NEW

### Step 2: Find the "Add Existing Field" Option

**Location varies by Drupal version:**

**Drupal 10/11:**
- On the "Manage fields" page
- Look for tabs: "Add new field" and "Add existing field"
- Click "Add existing field"

**If you don't see the tab:**
- Look for a dropdown or search box
- Drupal may auto-suggest existing fields
- Try typing the field name to search

### Step 3: Alternative - Use Unique Field Names

If you prefer separate fields entirely, use unique names:

**Instead of:**
- `field_title` (conflicts)

**Use:**
- `field_announcement_title`
- `field_blurb_title`
- `field_hero_title`

**Then update templates:**
- Templates reference field names
- Update `paragraph--announcement.html.twig` to use `field_announcement_title`
- Update `paragraph--blurb.html.twig` to use `field_blurb_title`

---

## Recommended Approach

### For This Theme:

**Option A: Reuse Fields (Recommended)**
- Create common fields once (e.g., `field_title` on Announcement)
- Reuse them for other paragraph types
- More efficient and maintainable
- Follows Drupal best practices

**Option B: Unique Field Names**
- Create uniquely named fields for each paragraph type
- More field management overhead
- But gives complete independence
- Requires template updates

---

## Quick Fix Checklist

If you're getting the error:

- [ ] Check if field already exists in Field list
- [ ] Use "Add existing field" instead of "Add new field"
- [ ] Select the field from the dropdown
- [ ] Configure settings for this paragraph type
- [ ] Save successfully

If you still have issues:

- [ ] Use a unique field name (e.g., `field_blurb_title`)
- [ ] Update the template to use new field name
- [ ] Clear Drupal cache

---

## Example: Setting Up All Paragraph Types

### First Paragraph Type: Announcement

```
1. Create NEW field: field_icon (Image)
2. Create NEW field: field_title (Text Plain) ← Create this
3. Create NEW field: field_message (Text Long)
4. Create NEW field: field_style (List Text)
5. Create NEW field: field_link (Link) ← Create this
6. Create NEW field: field_dismissible (Boolean)
```

### Second Paragraph Type: Blurb

```
1. ADD EXISTING: field_icon (reuse from Announcement) ✅
2. ADD EXISTING: field_title (reuse from Announcement) ✅
3. Create NEW field: field_image (Image)
4. Create NEW field: field_body (Text Long)
5. Create NEW field: field_alignment (List Text)
6. ADD EXISTING: field_link (reuse from Announcement) ✅
```

### Third Paragraph Type: Button

```
1. ADD EXISTING: field_link (reuse) ✅
2. Create NEW field: field_button_style (List Text)
3. Create NEW field: field_button_size (List Text)
4. Create NEW field: field_alignment (or reuse from Blurb if same options)
```

---

## Summary

**When you see "Machine name already in use":**

1. ✅ Don't try to create a new field with the same name
2. ✅ Use "Add existing field" to reuse it
3. ✅ Configure it for this specific paragraph type
4. ✅ Or use a unique field name if you prefer separation

**The field storage is shared, but each paragraph type can have different settings!**
