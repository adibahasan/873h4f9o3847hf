/**
 * @file
 * Mercury Editor JavaScript enhancements
 */

;(function (Drupal, $) {
  'use strict';

  var once = function ($elements, id) {
    return $elements.filter(function () {
      var $element = $(this);
      var key = 'once-' + id;
      if ($element.data(key)) {
        return false;
      }
      $element.data(key, true);
      return true;
    });
  };

  /**
   * Initialize Mercury Editor enhancements.
   */
  Drupal.behaviors.mercuryEditor = {
    attach: function (context, settings) {
      var $mercuryEditors = $('.mercury-editor', context);

      once($mercuryEditors, 'mercury-editor').each(function () {
        var $editor = $(this);
        var $content = $editor.find('.mercury-editor-content');

        // Auto-resize content area
        if ($content.length) {
          var autoResize = function () {
            $content.css('height', 'auto');
            $content.css('height', $content[0].scrollHeight + 'px');
          };

          $content.on('input', autoResize);
          autoResize(); // Initial resize
        }

        // Keyboard shortcuts
        $content.on('keydown', function (e) {
          // Bold: Ctrl/Cmd + B
          if ((e.ctrlKey || e.metaKey) && e.keyCode === 66) {
            e.preventDefault();
            document.execCommand('bold', false, null);
          }
          // Italic: Ctrl/Cmd + I
          if ((e.ctrlKey || e.metaKey) && e.keyCode === 73) {
            e.preventDefault();
            document.execCommand('italic', false, null);
          }
          // Underline: Ctrl/Cmd + U
          if ((e.ctrlKey || e.metaKey) && e.keyCode === 85) {
            e.preventDefault();
            document.execCommand('underline', false, null);
          }
        });

        // Update toolbar button states
        $editor.find('.mercury-toolbar-button').on('click', function (e) {
          e.preventDefault();
          var $button = $(this);
          var command = $button.data('command');
          var value = $button.data('value');

          if (command) {
            document.execCommand(command, false, value || null);
            
            // Update button active state
            if (command === 'formatBlock') {
              $editor.find('.mercury-toolbar-button').removeClass('active');
              $button.addClass('active');
            }
          }
        });
      });
    }
  };

})(Drupal, jQuery);
