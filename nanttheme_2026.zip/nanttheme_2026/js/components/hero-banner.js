/**
 * @file
 * Hero Banner Component JavaScript
 */

;(function (Drupal, $) {
  'use strict';

  var once = function ($elements, id) {
    if ($.fn.once) {
      return $elements.once(id);
    }
    return $elements.filter(function () {
      var $element = $(this);
      var key = 'once-' + id;
      if ($element.data(key)) {
        return false;
      }
      $element.data(key, true);
      return true;
    });
  };

  var debounce = Drupal.debounce || function (func, wait) {
    var timeout;
    return function () {
      var context = this;
      var args = arguments;
      clearTimeout(timeout);
      timeout = setTimeout(function () {
        func.apply(context, args);
      }, wait);
    };
  };

  /**
   * Initialize hero banner functionality.
   */
  Drupal.behaviors.heroBanner = {
    attach: function (context, settings) {
      var $heroBanners = $('.hero-banner', context);

      once($heroBanners, 'hero-banner').each(function () {
        var $banner = $(this);
        var $backgroundImage = $banner.find('.hero-banner__background-image');
        var $scrollIndicator = $banner.find('.hero-banner__scroll-indicator');

        // Parallax effect for background image (optional)
        if ($backgroundImage.length && $banner.hasClass('hero-banner--parallax')) {
          $(window).on('scroll', debounce(function () {
            var scrolled = $(window).scrollTop();
            var rate = scrolled * 0.5;
            $backgroundImage.css('transform', 'translateY(' + rate + 'px)');
          }, 10));
        }

        // Scroll indicator click handler
        if ($scrollIndicator.length) {
          $scrollIndicator.on('click', function (e) {
            e.preventDefault();
            var $nextSection = $banner.next('section, .page-main');
            if ($nextSection.length) {
              $('html, body').animate({
                scrollTop: $nextSection.offset().top - 80
              }, 800);
            }
          });
        }
      });
    }
  };

})(Drupal, jQuery);
