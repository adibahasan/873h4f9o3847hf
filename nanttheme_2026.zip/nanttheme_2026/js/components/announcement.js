/**
 * @file
 * Announcement Component JavaScript
 */

;(function (Drupal, $) {
  'use strict';

  var once = function ($elements, id) {
    return $elements.filter(function () {
      var $element = $(this);
      var key = 'once-' + id;
      if ($element.data(key)) {
        return false;
      }
      $element.data(key, true);
      return true;
    });
  };

  /**
   * Initialize announcement dismiss functionality.
   */
  Drupal.behaviors.announcement = {
    attach: function (context, settings) {
      var $announcements = $('.announcement', context);

      once($announcements, 'announcement').each(function () {
        var $announcement = $(this);
        var $closeButton = $announcement.find('.announcement__close');

        if ($closeButton.length) {
          $closeButton.on('click', function (e) {
            e.preventDefault();
            
            // Animate out
            $announcement.css({
              'opacity': '0',
              'max-height': $announcement.height() + 'px'
            });
            
            setTimeout(function () {
              $announcement.css({
                'max-height': '0',
                'padding': '0',
                'margin': '0',
                'overflow': 'hidden'
              });
              
              setTimeout(function () {
                $announcement.remove();
              }, 300);
            }, 150);
          });
        }
      });
    }
  };

})(Drupal, jQuery);
