/**
 * @file
 * Accordion Component JavaScript
 */

;(function (Drupal, $) {
  'use strict';

  var once = function ($elements, id) {
    return $elements.filter(function () {
      var $element = $(this);
      var key = 'once-' + id;
      if ($element.data(key)) {
        return false;
      }
      $element.data(key, true);
      return true;
    });
  };

  /**
   * Initialize accordion functionality.
   */
  Drupal.behaviors.accordion = {
    attach: function (context, settings) {
      var $accordionItems = $('[data-accordion-item]', context);

      once($accordionItems, 'accordion').each(function () {
        var $item = $(this);
        var $trigger = $item.find('.accordion__trigger');
        var $content = $item.find('.accordion__content');
        
        // Set initial state
        var isExpanded = $trigger.attr('aria-expanded') === 'true';
        $item.attr('data-expanded', isExpanded);

        // Handle click
        $trigger.on('click', function (e) {
          e.preventDefault();
          var $thisTrigger = $(this);
          var $thisItem = $thisTrigger.closest('[data-accordion-item]');
          var $thisContent = $thisItem.find('.accordion__content');
          var isCurrentlyExpanded = $thisTrigger.attr('aria-expanded') === 'true';

          // Toggle state
          if (isCurrentlyExpanded) {
            $thisTrigger.attr('aria-expanded', 'false');
            $thisItem.attr('data-expanded', 'false');
            $thisContent.css('max-height', '0');
          } else {
            // Close other items in the same accordion (optional - comment out if you want multiple open)
            var $parentAccordion = $thisItem.closest('.accordion');
            $parentAccordion.find('[data-accordion-item]').each(function () {
              var $otherItem = $(this);
              var $otherTrigger = $otherItem.find('.accordion__trigger');
              var $otherContent = $otherItem.find('.accordion__content');
              
              if ($otherItem[0] !== $thisItem[0]) {
                $otherTrigger.attr('aria-expanded', 'false');
                $otherItem.attr('data-expanded', 'false');
                $otherContent.css('max-height', '0');
              }
            });

            // Open clicked item
            $thisTrigger.attr('aria-expanded', 'true');
            $thisItem.attr('data-expanded', 'true');
            var scrollHeight = $thisContent.find('.accordion__content-inner')[0].scrollHeight;
            $thisContent.css('max-height', scrollHeight + 'px');
          }
        });

        // Set initial max-height if expanded
        if (isExpanded) {
          var scrollHeight = $content.find('.accordion__content-inner')[0].scrollHeight;
          $content.css('max-height', scrollHeight + 'px');
        }
      });
    }
  };

})(Drupal, jQuery);
