/**
 * @file
 * Main theme JavaScript file
 */

;(function (Drupal, $) {
  'use strict';

  var once = function ($elements, id) {
    return $elements.filter(function () {
      var $element = $(this);
      var key = 'once-' + id;
      if ($element.data(key)) {
        return false;
      }
      $element.data(key, true);
      return true;
    });
  };

  /**
   * Initialize theme functionality.
   */
  Drupal.behaviors.nanttheme2026 = {
    attach: function (context, settings) {
      // Smooth scroll for anchor links
      once($('a[href^="#"]', context), 'smooth-scroll').on('click', function (e) {
        var target = $(this.getAttribute('href'));
        if (target.length) {
          e.preventDefault();
          $('html, body').stop().animate({
            scrollTop: target.offset().top - 80
          }, 600);
        }
      });

      // Mobile menu toggle
      var $mobileMenuToggle = $('.mobile-menu-toggle', context);
      var $mobileMenu = $('.mobile-menu', context);

      once($mobileMenuToggle, 'mobile-menu').on('click', function (e) {
        e.preventDefault();
        $(this).toggleClass('is-active');
        $mobileMenu.toggleClass('is-open');
        $('body').toggleClass('menu-open');
      });

      // Close mobile menu on escape key
      once($(document), 'mobile-menu-escape').on('keydown', function (e) {
        if (e.keyCode === 27 && $mobileMenu.hasClass('is-open')) {
          $mobileMenuToggle.removeClass('is-active');
          $mobileMenu.removeClass('is-open');
          $('body').removeClass('menu-open');
        }
      });

      // Lazy loading images
      if ('loading' in HTMLImageElement.prototype) {
        var $images = $('img[loading="lazy"]', context);
        $images.each(function () {
          if (this.complete) {
            $(this).addClass('is-loaded');
          } else {
            $(this).on('load', function () {
              $(this).addClass('is-loaded');
            });
          }
        });
      }
    }
  };

  /**
   * Debounce function for performance optimization.
   */
  Drupal.debounce = function (func, wait, immediate) {
    var timeout;
    return function () {
      var context = this;
      var args = arguments;
      var later = function () {
        timeout = null;
        if (!immediate) {
          func.apply(context, args);
        }
      };
      var callNow = immediate && !timeout;
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
      if (callNow) {
        func.apply(context, args);
      }
    };
  };

})(Drupal, jQuery);
