// Ensure Drupal and jQuery are available
window.Drupal = window.Drupal || { 
    behaviors: {}, 
    is_standalone: true 
};

// if standalone, invoke all behaviors attach methods on document ready
// When viewed in Drupal portal, the attach methods are automaticallyinvoked.
(function (Drupal, $) {
    if (Drupal.is_standalone) {
        $(document).ready(function () {
            $.each(Drupal.behaviors, function (behaviorName, behavior) {
                if (typeof behavior.attach === 'function') {
                    behavior.attach(document);
                }
            });
        });
    }       
})(Drupal, jQuery);
