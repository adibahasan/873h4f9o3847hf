# Installation Guide - NantTheme 2026

Complete step-by-step guide for installing and configuring NantTheme 2026 on your Drupal site.

---

## Prerequisites

Before installing the theme, ensure you have:

- **Drupal 10** or **Drupal 11** installed
- Admin access to your Drupal site
- Access to the file system (FTP, SSH, or direct server access)
- (Optional) Drush installed for command-line operations

---

## Installation Methods

### Method 1: Manual Installation (Recommended)

#### Step 1: Locate Your Drupal Installation

Find your Drupal installation directory. The typical structure is:
```
/var/www/html/
├── web/                    # Drupal core files
│   ├── core/
│   ├── modules/
│   ├── themes/
│   │   ├── contrib/       # Contributed themes
│   │   └── custom/        # Custom themes (create if needed)
│   └── sites/
└── ...
```

#### Step 2: Upload Theme Files

1. **Navigate to the themes directory:**
   ```bash
   cd /path/to/drupal/web/themes/custom
   ```

2. **Upload the entire theme folder:**
   - The theme folder name should be: `nanttheme_2026`
   - Full path should be: `/web/themes/custom/nanttheme_2026/`

3. **Verify the structure:**
   The theme should contain these key files:
   ```
   nanttheme_2026/
   ├── nanttheme_2026.info.yml
   ├── nanttheme_2026.libraries.yml
   ├── nanttheme_2026.theme
   ├── templates/
   ├── css/
   └── js/
   ```

#### Step 3: Set Proper Permissions

Ensure the web server can read the theme files:
```bash
# Set ownership (adjust user/group as needed)
sudo chown -R www-data:www-data /path/to/drupal/web/themes/custom/nanttheme_2026

# Set permissions
sudo chmod -R 755 /path/to/drupal/web/themes/custom/nanttheme_2026
```

---

### Method 2: Using Git

If your theme is in a Git repository:

```bash
cd /path/to/drupal/web/themes/custom
git clone [your-repository-url] nanttheme_2026
cd nanttheme_2026
```

---

### Method 3: Using Composer (Advanced)

If using Composer for dependency management:

1. **Add to your composer.json:**
   ```json
   {
     "repositories": [
       {
         "type": "path",
         "url": "./web/themes/custom/nanttheme_2026"
       }
     ],
     "require": {
       "nanthealth/nanttheme-2026": "@dev"
     }
   }
   ```

2. **Install:**
   ```bash
   composer require nanthealth/nanttheme-2026:@dev
   ```

---

## Enable the Theme

### Option 1: Using Drupal Admin Interface

1. **Navigate to the Appearance page:**
   - Go to: **Appearance** (`/admin/appearance`)
   - Or: **Administration > Appearance**

2. **Find NantTheme 2026:**
   - Scroll down to the "Custom" section
   - You should see "NantTheme 2026" listed

3. **Install and Set as Default:**
   - Click **"Install and set as default"** button
   - Or click **"Install"**, then click **"Set as default"**

4. **Verify:**
   - The theme should now show as "Set as default" with a checkmark

### Option 2: Using Drush (Command Line)

```bash
# Enable the theme
drush theme:enable nanttheme_2026

# Set as default theme
drush config:set system.theme default nanttheme_2026

# Clear cache
drush cache:rebuild
```

### Option 3: Using Drupal Console (If Available)

```bash
drupal theme:install nanttheme_2026
drupal theme:default nanttheme_2026
drupal cache:rebuild
```

---

## Post-Installation Steps

### Step 1: Clear Cache

**Via Admin Interface:**
- Go to **Configuration > Development > Performance**
- Click **"Clear all caches"**

**Via Drush:**
```bash
drush cache:rebuild
```

**Via Drupal Console:**
```bash
drupal cache:rebuild
```

### Step 2: Install Required Modules (If Using Paragraph Types)

If you plan to use paragraph types, install the Paragraphs module:

```bash
drush en paragraphs paragraphs_library -y
drush cache:rebuild
```

Or via admin interface:
- Go to **Extend** (`/admin/modules`)
- Search for "Paragraphs"
- Check the box and click **"Install"**

### Step 3: Configure Block Layout

1. **Go to Block Layout:**
   - Navigate to **Structure > Block layout** (`/admin/structure/block`)

2. **Assign Blocks to Regions:**
   The theme provides these regions:
   - Header
   - Primary Menu
   - Secondary Menu
   - Breadcrumb
   - Highlighted
   - Help
   - Content
   - Sidebar First
   - Sidebar Second
   - Footer First
   - Footer Second
   - Footer Third
   - Footer Fourth
   - Footer

3. **Place blocks as needed:**
   - Click **"Place block"** next to any region
   - Select a block to place
   - Configure and save

### Step 4: Ensure Admin UI Looks OK

To keep the Drupal admin area clean and consistent, set a dedicated admin theme (recommended: Claro) and enable the admin theme for content editing pages.

**Via Admin Interface:**
- Go to **Appearance** (`/admin/appearance`)
- Under **Administration theme**, select **Claro**
- Enable **"Use the administration theme when editing or creating content"**
- Save configuration

**Via Drush:**
```bash
# Set admin theme
drush config:set system.theme admin claro -y

# Use admin theme on edit/create pages
drush config:set system.theme use_admin_theme 1 -y

# Clear cache
drush cache:rebuild
```

---

## Verify Installation

### Check Theme Files

1. **Verify theme appears in admin:**
   - Go to `/admin/appearance`
   - "NantTheme 2026" should be listed

2. **Check theme settings:**
   - Click **"Settings"** next to the theme
   - Verify all options are accessible

3. **View your site:**
   - Visit the front page
   - Check that theme styles are applied
   - Inspect page source to verify CSS/JS are loading

4. **Check admin UI:**
   - Visit `/admin` after logging in
   - Confirm Claro (or your chosen admin theme) is active
   - Verify forms and tables render correctly

### Troubleshooting Installation

**Theme not appearing in admin:**

1. **Check file permissions:**
   ```bash
   ls -la /path/to/drupal/web/themes/custom/nanttheme_2026
   ```
   Files should be readable (644) and directories executable (755)

2. **Verify info.yml file:**
   ```bash
   cat /path/to/drupal/web/themes/custom/nanttheme_2026/nanttheme_2026.info.yml
   ```
   Should show valid YAML content

3. **Check Drupal version compatibility:**
   - Theme requires Drupal 10 or 11
   - Check your Drupal version: `drush status`

4. **Clear cache:**
   ```bash
   drush cache:rebuild
   ```

**Styles not loading:**

1. **Check libraries.yml:**
   - Verify `nanttheme_2026.libraries.yml` exists and has correct paths

2. **Clear all caches:**
   ```bash
   drush cache:rebuild
   drush cr
   ```

3. **Check browser console:**
   - Open browser Developer Tools
   - Look for 404 errors on CSS/JS files
   - Verify file paths are correct

**JavaScript not working:**

1. **Verify jQuery is loaded:**
   - Check browser console for jQuery errors
   - Theme requires jQuery (usually provided by Drupal core)

2. **Check file permissions:**
   - Ensure JS files are readable

3. **Clear cache:**
   ```bash
   drush cache:rebuild
   ```

---

## Next Steps

After successful installation:

1. **Configure Theme Settings:**
   - Go to **Appearance > Settings > NantTheme 2026**
   - Customize theme-specific options if available

2. **Set Up Paragraph Types:**
   - See `PARAGRAPH_TYPES_GUIDE.md` for complete instructions
   - Install Paragraphs module if needed
   - Create paragraph types for your components

3. **Customize CSS Variables:**
   - Edit `css/base/variables.css` to customize colors, spacing, etc.
   - Clear cache after making changes

4. **Configure Menus:**
   - Go to **Structure > Menus**
   - Assign menus to Primary Menu and Secondary Menu regions

5. **Review Templates:**
   - Check `templates/` directory for available templates
   - Customize as needed for your site

---

## File Structure Reference

After installation, your theme structure should be:

```
web/themes/custom/nanttheme_2026/
├── nanttheme_2026.info.yml          # Theme definition
├── nanttheme_2026.libraries.yml     # Asset libraries
├── nanttheme_2026.theme             # Theme hooks
├── composer.json                    # Composer config
├── README.md                        # Theme documentation
├── PARAGRAPH_TYPES_GUIDE.md        # Paragraph types guide
├── INSTALLATION.md                  # This file
├── css/                             # Stylesheets
│   ├── base/                        # Base styles
│   ├── components/                  # Component styles
│   ├── layout/                      # Layout styles
│   ├── mercury/                     # Mercury editor styles
│   └── utilities/                   # Utility classes
├── js/                              # JavaScript
│   ├── components/                  # Component scripts
│   ├── mercury/                     # Mercury editor scripts
│   └── theme.js                     # Main theme script
├── templates/                       # Twig templates
│   ├── components/                  # Component templates
│   ├── content/                     # Content templates
│   ├── layout/                      # Layout templates
│   └── paragraphs/                  # Paragraph templates
├── images/                          # Theme images
└── ComponentIcons/                  # Component icons
```

---

## Quick Installation Checklist

- [ ] Drupal 10 or 11 installed
- [ ] Theme folder uploaded to `/web/themes/custom/nanttheme_2026/`
- [ ] File permissions set correctly (755 for directories, 644 for files)
- [ ] Theme enabled in Drupal admin
- [ ] Theme set as default
- [ ] Admin theme set (recommended: Claro)
- [ ] Admin theme used for edit/create pages
- [ ] Cache cleared
- [ ] Site frontend displays with theme styles
- [ ] CSS and JavaScript files loading (check browser console)
- [ ] (Optional) Paragraphs module installed if using paragraph types

---

## Support

If you encounter issues during installation:

1. **Check logs:**
   - Drupal logs: `/admin/reports/dblog`
   - Server error logs: Check your web server logs

2. **Verify requirements:**
   - Drupal version compatibility
   - PHP version (Drupal 10+ requires PHP 8.1+)
   - File permissions

3. **Common solutions:**
   - Clear all caches
   - Check file paths
   - Verify file permissions
   - Review browser console for errors

4. **Get help:**
   - Review `README.md` for theme overview
   - Check `PARAGRAPH_TYPES_GUIDE.md` for paragraph setup
   - Contact your development team

---

## Uninstallation

To remove the theme:

1. **Switch to another theme first:**
   - Go to **Appearance**
   - Set a different theme as default
   - Uninstall NantTheme 2026

2. **Delete theme files:**
   ```bash
   rm -rf /path/to/drupal/web/themes/custom/nanttheme_2026
   ```

3. **Clear cache:**
   ```bash
   drush cache:rebuild
   ```

**Note:** Make sure you're using a different theme before deleting files, or your site may break!
