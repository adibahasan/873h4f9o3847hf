# NantTheme 2026 – Version Log

A detailed log of changes organized by component and area.

---

## Version 1.0.2 – 2026-02-04

### Accordion Component
| Change | Details |
|--------|---------|
| **Content padding** | Added 15px padding above paragraph content in accordion items (`.accordion__content-inner`). Applies between the trigger title and body text. |

**Files:** `css/components/accordion.css`

---

### Blurb Component
| Change | Details |
|--------|---------|
| **Left-aligned layout** | Image/icon now displays on the left side of header and paragraph text using flexbox. Content flows beside the image. |
| **Centered blurb image** | Replaced icon with image support. Centered blurb can now display a featured image. |
| **Stock images** | Both centered and left-aligned blurbs use Pexels medical stock images (doctors/nurses, healthcare provider). |
| **Copy update** | Replaced "icon" with "image" in all blurb body text. |
| **Expanded content** | Added additional paragraphs to both blurbs for richer showcase content. |

**Files:** `css/components/blurb.css`, `COMPONENT_SHOWCASE.html`

---

### Button Component
| Change | Details |
|--------|---------|
| **Unified button size** | Default button size set to match primary/large (padding: `var(--spacing-md) var(--spacing-xl)`, font-size: `var(--font-size-lg)`). |
| **Small button preserved** | `.button--small` sizing left unchanged. |
| **Cross-component consistency** | Hero banner buttons, blurb action buttons, and default `.button` all use the same size. |

**Files:** `css/components/buttons.css`, `css/components/hero-banner.css`, `css/components/blurb.css`, `COMPONENT_SHOWCASE.html`

---

### Card Grid Component
| Change | Details |
|--------|---------|
| **First card image** | Replaced placeholder with Pexels medical stock image (doctor with pills and stethoscope). |

**Files:** `COMPONENT_SHOWCASE.html`

---

### Header Component
| Change | Details |
|--------|---------|
| **Optional tag links** | Tags/keywords can optionally be links. New field `field_tag_links` (Link, Unlimited) – one URL per tag. |
| **Template update** | Template checks for `field_tag_links` and wraps tag text in `<a>` when URL is present. |
| **Link styling** | Added `.header-component__tag-link` styles. |

**Files:** `templates/paragraphs/paragraph--header-component.html.twig`, `css/components/header-component.css`, `COMPONENT_SHOWCASE.html`, `PARAGRAPH_TYPES_GUIDE.md`

---

### Image Component
| Change | Details |
|--------|---------|
| **Sample image** | Replaced gradient placeholder with Pexels medical stock image. |

**Files:** `COMPONENT_SHOWCASE.html`

---

### List Component
| Change | Details |
|--------|---------|
| **Optional item links** | Each list item can optionally be a link. New field `field_list_item_links` (Link, Unlimited) – one URL per item. |
| **Template update** | Template checks for `field_list_item_links` and wraps item text in `<a>` when URL is present. |
| **Link styling** | Added `.list-component__item-link` styles. |

**Files:** `templates/paragraphs/paragraph--list.html.twig`, `css/components/list.css`, `COMPONENT_SHOWCASE.html`, `PARAGRAPH_TYPES_GUIDE.md`

---

### Typography
| Change | Details |
|--------|---------|
| **Inter font** | Set Inter as the primary font for all text. |
| **Variables** | `--font-family-base` and `--font-family-heading` now use `'Inter'` with system font fallbacks. |
| **Google Fonts** | Inter (weights 400, 500, 600, 700, 800) loaded via Google Fonts in theme library. |

**Files:** `css/base/variables.css`, `nanttheme_2026.libraries.yml`

---

### Documentation
| Change | Details |
|--------|---------|
| **List paragraph** | Documented `field_list_item_links` in PARAGRAPH_TYPES_GUIDE.md. |
| **Header component** | Documented `field_tag_links` in PARAGRAPH_TYPES_GUIDE.md. |

**Files:** `PARAGRAPH_TYPES_GUIDE.md`

---

## Summary by File

| File | Changes |
|------|---------|
| `css/components/accordion.css` | Content top padding |
| `css/components/blurb.css` | Flex layout for left-align, action button size |
| `css/components/buttons.css` | Default button size |
| `css/components/header-component.css` | Tag link styles |
| `css/components/hero-banner.css` | Button font-size |
| `css/components/list.css` | Item link styles |
| `css/base/variables.css` | Inter font family |
| `nanttheme_2026.libraries.yml` | Google Fonts (Inter) |
| `templates/paragraphs/paragraph--header-component.html.twig` | Tag link support |
| `templates/paragraphs/paragraph--list.html.twig` | Item link support |
| `COMPONENT_SHOWCASE.html` | Images, links, copy, button classes |
| `PARAGRAPH_TYPES_GUIDE.md` | New fields documented |

---

## Drupal Setup Required

For new features to work in Drupal:

1. **List paragraph type:** Add `field_list_item_links` (Link, Unlimited).
2. **Header Component paragraph type:** Add `field_tag_links` (Link, Unlimited).
3. Run `drush cr` after adding fields.
