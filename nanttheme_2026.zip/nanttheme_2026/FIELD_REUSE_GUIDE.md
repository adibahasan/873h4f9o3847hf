# Field Reuse Guide - Paragraph Types

## ⚠️ Important: Machine Name Conflicts

If you get the error: **"The machine-readable name is already in use. It must be unique."**

This means a field with that machine name already exists in Drupal. You have two options:

---

## Solution 1: Reuse Existing Field (Recommended)

When Drupal shows a field already exists, you can **add it to another paragraph type**:

### Steps to Reuse an Existing Field:

1. **When creating a field, if you see "Add existing field" option:**
   - Look for the field name in the dropdown (e.g., `field_title`)
   - Select it from the existing fields list
   - Click "Save and continue"

2. **If you don't see the option:**
   - Drupal will automatically detect existing fields
   - Use the "Add existing field" tab instead of "Add new field"

3. **Configure for this paragraph type:**
   - The field storage is shared
   - But you configure settings specific to this paragraph type
   - Each paragraph type can have different settings

### Example:

**Creating `field_title` for Announcement (first time):**
- Click "Add new field"
- Select "Text (Plain)" 
- Machine name: `field_title`
- Configure and save

**Creating `field_title` for Blurb (field already exists):**
- Click **"Add existing field"** (or Drupal shows this option)
- Select `field_title` from dropdown
- Configure settings for Blurb
- Save

**Result:** Both paragraph types use the same field storage, but each has its own configuration.

---

## Solution 2: Use Unique Field Names (Alternative)

If you prefer separate field storage entirely, use unique machine names by adding a prefix:

### Naming Convention with Prefix:

Instead of reusing, you can create uniquely named fields:

**Option A: Prefix with paragraph type name**
```
Announcement:
  - field_announcement_title
  - field_announcement_link

Blurb:
  - field_blurb_title
  - field_blurb_link
```

**Option B: Keep common fields generic, make unique ones specific**
```
Common fields (reuse these):
  - field_title (reuse across types)
  - field_link (reuse across types)

Unique fields (separate):
  - field_announcement_style
  - field_blurb_alignment
```

---

## Understanding Field Storage vs Field Instance

### Field Storage (Shared)
- Database table structure
- Shared across all bundles using that field
- Must have unique machine name across entire Drupal installation

### Field Instance (Per Bundle)
- Configuration specific to each paragraph type
- Settings can differ per bundle
- Multiple bundles can use same field storage

---

## Best Practice Recommendation

### ✅ Recommended: Reuse Fields with Same Name

**When fields have the same:**
- Field type (e.g., Text Plain)
- Basic purpose (e.g., title, link, image)
- Similar data structure

**Reuse them:**
- Use "Add existing field" when prompted
- Configure settings per paragraph type
- More efficient and maintainable

**Example reusable fields:**
- `field_title` - Used in many paragraph types
- `field_link` - Used in many paragraph types  
- `field_image` - Used in many paragraph types
- `field_alignment` - Used in multiple types

### ✅ Use Unique Names When:

**Fields have different:**
- Field types
- Specific purposes
- Different configurations needed

**Make them unique:**
- `field_hero_image` (not `field_image`)
- `field_section_title` (not `field_title`)
- `field_button_style` (specific purpose)

---

## Step-by-Step: Adding Fields to Multiple Paragraph Types

### Scenario: Adding `field_title` to Multiple Types

**First Paragraph Type (Announcement):**

1. Go to: **Structure > Paragraph types > Announcement > Manage fields**
2. Click **"Add new field"**
3. Select: **Text (Plain)**
4. Machine name: `field_title`
5. Configure settings
6. Save

**Second Paragraph Type (Blurb) - Field Already Exists:**

1. Go to: **Structure > Paragraph types > Blurb > Manage fields**
2. Click **"Add existing field"** tab (or it may auto-detect)
3. Select: `field_title` from dropdown
4. Configure settings for Blurb (can be different from Announcement)
5. Save

**Note:** The field storage is shared, but each paragraph type can have different:
- Required/optional settings
- Help text
- Default values
- Display settings

---

## Common Fields You Can Reuse

These fields appear in multiple paragraph types - **reuse them** when possible:

| Field Name | Field Type | Used In |
|------------|------------|---------|
| `field_title` | Text (Plain) | Announcement, Blurb, Header, Hero, Link Grid Item, Section |
| `field_link` | Link | Announcement, Blurb, Button, Image, Link Grid Item |
| `field_image` | Image | Blurb, Image |
| `field_icon` | Image | Announcement, Blurb |
| `field_alignment` | List (Text) | Blurb, Button, Image |

When adding these to a second/third paragraph type, use **"Add existing field"**.

---

## Troubleshooting

### Error: "Machine-readable name is already in use"

**Solution 1 - Reuse the field:**
- Click "Add existing field" tab
- Select the field from the dropdown
- Configure for this paragraph type

**Solution 2 - Use unique name:**
- Add a prefix: `field_announcement_title` instead of `field_title`
- Or add a suffix: `field_title_blurb`
- Update templates to match new field name

### Can't find field in "Add existing field" dropdown?

**Possible reasons:**
- Field doesn't exist yet (create it as new first)
- Field type mismatch (can't reuse Text field as Image field)
- Field is on different entity type

**Solution:**
- Create as new field first
- Then reuse it for other paragraph types

### Field storage shared but need different settings?

**Solution:**
- Field storage is shared (data structure)
- Field instance settings can differ per paragraph type
- Configure settings independently for each paragraph type

---

## Updated Field Creation Workflow

### Recommended Process:

1. **Create common fields first:**
   - Start with fields used in multiple paragraph types
   - Create them as "new fields" on the first paragraph type
   - Examples: `field_title`, `field_link`, `field_image`

2. **Reuse for other paragraph types:**
   - Use "Add existing field" for subsequent types
   - Configure settings per paragraph type
   - More efficient and consistent

3. **Create unique fields:**
   - For fields specific to one paragraph type
   - Use descriptive unique names
   - Examples: `field_button_style`, `field_announcement_dismissible`

---

## Example: Complete Field Setup

### Announcement Paragraph Type (Create New Fields)

```
field_icon - Image (new)
field_title - Text Plain (new) ← Create this first
field_message - Text Long (new)
field_style - List Text (new)
field_link - Link (new) ← Create this first
field_dismissible - Boolean (new)
```

### Blurb Paragraph Type (Reuse + New)

```
field_icon - Image (existing - reuse from Announcement)
field_image - Image (new)
field_title - Text Plain (existing - reuse from Announcement) ✅
field_body - Text Long (new)
field_alignment - List Text (new)
field_link - Link (existing - reuse from Announcement) ✅
```

### Button Paragraph Type (Reuse + New)

```
field_link - Link (existing - reuse) ✅
field_button_style - List Text (new - unique name)
field_button_size - List Text (new - unique name)
field_alignment - List Text (existing - reuse from Blurb) ✅
```

---

## Summary

✅ **DO:**
- Reuse fields with same name and type when prompted
- Use "Add existing field" for fields already created
- Configure settings per paragraph type (even when reusing)
- Create unique names for fields with specific purposes

❌ **DON'T:**
- Try to create duplicate field storage manually
- Ignore the "Add existing field" option
- Use unnecessarily unique names when fields can be shared

---

## Quick Decision Tree

**When creating a field:**

```
Is this field already used in another paragraph type?
│
├─ YES → Use "Add existing field" ✅
│         Select from dropdown
│         Configure for this paragraph type
│
└─ NO → Create as "Add new field" ✅
          Set machine name
          Configure settings
          Save (can be reused later)
```

---

## Need Help?

If you encounter issues:
1. Check if field already exists: **Structure > Configuration > Field list**
2. Try "Add existing field" first
3. If that doesn't work, use unique field name with prefix
4. Update templates to match field names if needed

**Remember:** Reusing fields is more efficient and is the recommended Drupal approach!