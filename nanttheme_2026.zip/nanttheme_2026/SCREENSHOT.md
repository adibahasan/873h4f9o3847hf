# Theme Screenshot

This theme includes a screenshot image that appears on the Drupal Appearance page (`/admin/appearance`).

## Files

- **screenshot.png** - The PNG screenshot image (294x219 pixels)
- **screenshot.svg** - Source SVG file (can be edited and regenerated)

## Configuration

The screenshot is configured in `nanttheme_2026.info.yml`:

```yaml
screenshot: screenshot.png
```

Drupal will automatically detect and display this screenshot on the Appearance page.

## Dimensions

- **Standard Drupal screenshot size:** 294x219 pixels
- **Aspect ratio:** ~4:3

## Updating the Screenshot

If you need to update the screenshot:

1. **Edit the SVG source:**
   - Edit `screenshot.svg` with any SVG editor
   - Save your changes

2. **Regenerate PNG:**
   ```bash
   # Using ImageMagick
   convert -background transparent -size 294x219 screenshot.svg screenshot.png
   
   # Or using magick (ImageMagick v7)
   magick -background transparent -size 294x219 screenshot.svg screenshot.png
   ```

3. **Clear Drupal cache:**
   ```bash
   drush cache:rebuild
   ```

## Design

The screenshot showcases:
- Theme header with logo and tags
- Hero section with buttons
- Section component with grid items
- Footer styling

All elements use the theme's brand colors and design system to give a preview of the theme's appearance.

## Alternative Formats

Drupal also supports:
- `screenshot.jpg` - JPEG format
- `screenshot.png` - PNG format (recommended)

If both exist, PNG takes precedence. The screenshot file should be placed in the theme root directory.
