# NantTheme 2026

A modern, component-based Drupal theme for 2026 with Mercury editor support.

## Table of Contents

- [NantTheme 2026](#nanttheme-2026)
  - [Table of Contents](#table-of-contents)
  - [Features](#features)
  - [Structure](#structure)
  - [Components](#components)
    - [Card Grid](#card-grid)
    - [Hero Banner](#hero-banner)
  - [Installation](#installation)
    - [Quick Installation](#quick-installation)
    - [Admin UI (Recommended)](#admin-ui-recommended)
  - [Configuration](#configuration)
    - [CSS Variables](#css-variables)
    - [Regions](#regions)
  - [Mercury Editor](#mercury-editor)
  - [Browser Support](#browser-support)
  - [Development](#development)
    - [Adding New Components](#adding-new-components)
    - [CSS Architecture](#css-architecture)
    - [Building the NaviNet Assets](#building-the-navinet-assets)
  - [License](#license)
  - [Paragraph Types](#paragraph-types)
    - [Available Paragraph Types](#available-paragraph-types)
  - [Support](#support)

## Features

- **Component-Based Architecture**: Modular, reusable components
- **Mercury Editor Support**: Enhanced styling and functionality for Mercury editor
- **Modern CSS**: Uses CSS custom properties (variables) for easy theming
- **Responsive Design**: Mobile-first approach with flexible grid system
- **Accessibility**: WCAG compliant markup and ARIA attributes
- **Performance**: Optimized assets and lazy loading support

## Structure

```
nanttheme_2026/
├── css/
│   ├── base/              # Base styles (variables, reset, typography, layout)
│   ├── components/        # Component-specific styles
│   ├── layout/            # Page layout styles
│   ├── mercury/           # Mercury editor styles
│   └── utilities/         # Utility classes
├── js/
│   ├── components/        # Component JavaScript
│   ├── mercury/           # Mercury editor JavaScript
│   └── theme.js           # Main theme JavaScript
|   |__ navinet-assets     # Bundled css and js assets
├── templates/
│   ├── components/        # Component Twig templates
│   ├── content/           # Content templates (node)
│   ├── layout/            # Layout Twig templates
│   └── paragraphs/        # Paragraph type templates
├── images/                # Theme images
├── nanttheme_2026.info.yml
├── nanttheme_2026.libraries.yml
├── nanttheme_2026.theme
└── composer.json
```

## Components

### Card Grid

A flexible grid system for displaying cards in various column layouts.

**Usage:**
```twig
{% include '@nanttheme_2026/components/card-grid.html.twig' with {
  'cards': cards_array,
  'columns': 3,
  'spacing': 'medium'
} %}
```

**Card structure:**
```php
$card = [
  'title' => 'Card Title',
  'content' => 'Card description...',
  'image' => '/path/to/image.jpg',
  'link' => '/path/to/page',
  'link_text' => 'Learn More',
  'variant' => 'default' // default, featured, minimal
];
```

### Hero Banner

Full-width hero banner with background images, overlays, and call-to-action buttons.

**Usage:**
```twig
{% include '@nanttheme_2026/components/hero-banner.html.twig' with {
  'title': 'Welcome to Our Site',
  'subtitle': 'This is a subtitle',
  'background_image': '/path/to/image.jpg',
  'overlay': 'dark', // dark, light, none
  'size': 'medium',  // small, medium, large, full-height
  'alignment': 'center', // left, center, right
  'buttons': [
    {
      'text': 'Get Started',
      'url': '/start',
      'style': 'primary'
    }
  ],
  'show_scroll_indicator': true
} %}
```

## Installation

**📖 For detailed installation instructions, see [INSTALLATION.md](INSTALLATION.md)**

### Quick Installation

1. Copy the theme folder to your Drupal `themes/custom/` directory
   - Path should be: `/web/themes/custom/nanttheme_2026/`

2. Enable the theme:

   **Via Drupal Admin:**
   - Go to **Appearance** (`/admin/appearance`)
   - Click **"Install and set as default"** for NantTheme 2026

   **Via Drush:**
   ```bash
   drush theme:enable nanttheme_2026
   drush config:set system.theme default nanttheme_2026
   drush cache:rebuild
   ```

3. Clear cache and verify installation

### Admin UI

Set Claro as the admin theme for Drupal's standard admin look:

```bash
drush config:set system.theme admin claro -y
drush config:set system.theme use_admin_theme 1 -y
drush cache:rebuild
```

**See [INSTALLATION.md](INSTALLATION.md) for:**
- Complete step-by-step instructions
- Troubleshooting guide
- Post-installation configuration
- File structure reference

## Configuration

### CSS Variables

The theme uses CSS custom properties for easy customization. Edit `css/base/variables.css` to change:

- Colors
- Typography
- Spacing
- Breakpoints
- Shadows
- Transitions

### Regions

The theme provides the following regions:

- Header
- Primary Menu
- Secondary Menu
- Breadcrumb
- Highlighted
- Help
- Content
- Sidebar First
- Sidebar Second
- Footer First
- Footer Second
- Footer Third
- Footer Fourth
- Footer

## Mercury Editor

The theme includes enhanced styles and JavaScript for Mercury editor integration. The Mercury editor library is automatically loaded when needed.

**Classes:**
- `.mercury-editor` - Main editor container
- `.mercury-toolbar` - Toolbar wrapper
- `.mercury-editor-content` - Content area

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- IE11 (with polyfills)

## Development

### Adding New Components

1. Create component template in `templates/components/`
2. Create component styles in `css/components/`
3. Add component library to `nanttheme_2026.libraries.yml`
4. Create JavaScript file if needed in `js/components/`

### CSS Architecture

The theme follows a modular CSS architecture:

1. **Base**: Variables, reset, typography, layout utilities
2. **Components**: Reusable component styles
3. **Layout**: Page-level layout styles
4. **Utilities**: Utility classes for common patterns

### Building the NaviNet Assets
> **⚠️ Important:** Every new theme version **must** include freshly bundled assets **before deployment**.

Build the assets using the following steps, required npm. 
* From the theme folder `npm i && npm run build`
  * this will generated new bundles under the `navinet-assets` folder
* update the `navinet-assets` library in [library.yaml](./nanttheme_2026.libraries.yml) with the new bundle file names


## License

GPL-2.0-or-later

## Paragraph Types

This theme includes support for multiple paragraph types for building flexible page layouts.

**📖 See [PARAGRAPH_TYPES_GUIDE.md](PARAGRAPH_TYPES_GUIDE.md) for complete documentation**, including:

- All paragraph types and their field configurations
- Step-by-step setup instructions
- Template locations and styling
- Troubleshooting guide

### Available Paragraph Types

All 11 paragraph types are active with templates and styling:

- Accordion
- Announcement
- Blurb
- Button
- Image
- List (checklist or bullet styling)
- Site Accent Color
- Header Component
- Hero Component
- Section Component
- Footer Component

## Support

For issues and questions, please contact the development team.
