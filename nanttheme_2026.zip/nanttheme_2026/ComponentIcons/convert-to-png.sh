#!/bin/bash
# Convert SVG icons to 64x64 PNG files
# Requires ImageMagick: brew install imagemagick (on macOS)

echo "Converting SVG icons to 64x64 PNG files..."

for svg_file in *.svg; do
    if [ -f "$svg_file" ]; then
        # Get filename without extension
        png_file="${svg_file%.svg}.png"
        
        echo "Converting $svg_file to $png_file..."
        
        # Convert SVG to PNG using ImageMagick
        convert -background transparent -size 64x64 "$svg_file" "$png_file"
        
        if [ $? -eq 0 ]; then
            echo "✓ Successfully created $png_file"
        else
            echo "✗ Failed to convert $svg_file"
        fi
    fi
done

echo ""
echo "Conversion complete!"
echo ""
echo "If ImageMagick is not installed:"
echo "  macOS: brew install imagemagick"
echo "  Ubuntu/Debian: sudo apt-get install imagemagick"
echo "  Or use online tools: https://convertio.co/svg-png/"
