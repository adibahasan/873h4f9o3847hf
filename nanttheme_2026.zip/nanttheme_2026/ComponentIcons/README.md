# Component Icons

This directory contains SVG icons for all paragraph type components in the theme.

## Icons Included

1. **accordion.svg** - Accordion component icon
2. **announcement.svg** - Announcement component icon
3. **blurb.svg** - Blurb component icon
4. **button.svg** - Button component icon
5. **image.svg** - Image component icon
6. **header-component.svg** - Header Component icon
7. **hero-component.svg** - Hero Component icon
8. **section-component.svg** - Section Component icon
9. **link-grid-item.svg** - Link Grid Item component icon
10. **footer-component.svg** - Footer Component icon

## Usage

These SVG icons can be used to identify components in the Drupal admin interface, documentation, or UI elements.

### Converting to PNG

These SVG files can be used directly in browsers and many applications. To convert them to 64x64 transparent PNG files:

**Quick Conversion (Automated):**

**Option 1: Using the provided shell script (ImageMagick):**
```bash
cd ComponentIcons
./convert-to-png.sh
```
*Requires ImageMagick: `brew install imagemagick` (macOS) or `sudo apt-get install imagemagick` (Linux)*

**Option 2: Using the provided Node.js script:**
```bash
cd ComponentIcons
npm install -g svgexport  # First time only
node convert-to-png.js
```

**Manual Conversion:**

**Using ImageMagick:**
```bash
convert -background transparent -size 64x64 icon.svg icon.png
```

**Using Inkscape (command line):**
```bash
inkscape --export-filename=icon.png --export-width=64 --export-height=64 icon.svg
```

**Using Online Tools:**
- https://convertio.co/svg-png/
- https://cloudconvert.com/svg-to-png
- https://svgtopng.com/

**Individual file conversion (svgexport):**
```bash
npm install -g svgexport
svgexport icon.svg icon.png 64:64
```

## Design Notes

All icons are designed with:
- 64x64 viewBox for consistency
- Transparent background
- Brand colors (#26478E) matching the theme
- Simple, recognizable representations of each component
- Consistent stroke width and styling

## Color Palette

- Primary Brand: `#26478E`
- Background: `#FFFFFF`, `#F9FCFD`, `#F3F9FB`
- Borders: `#E2ECF4`
- Accents: `#DAECF4`
- Text: `#4B5563`, `#1F2937`
