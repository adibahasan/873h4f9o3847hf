/**
 * Convert SVG icons to 64x64 PNG files using Node.js
 * 
 * Requirements:
 *   npm install -g svgexport
 * 
 * Usage:
 *   node convert-to-png.js
 */

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const svgFiles = fs.readdirSync(__dirname).filter(file => file.endsWith('.svg'));

console.log('Converting SVG icons to 64x64 PNG files...\n');

svgFiles.forEach(svgFile => {
  const svgPath = path.join(__dirname, svgFile);
  const pngFile = svgFile.replace('.svg', '.png');
  const pngPath = path.join(__dirname, pngFile);
  
  try {
    console.log(`Converting ${svgFile} to ${pngFile}...`);
    execSync(`svgexport "${svgPath}" "${pngPath}" 64:64`, { stdio: 'inherit' });
    console.log(`✓ Successfully created ${pngFile}\n`);
  } catch (error) {
    console.error(`✗ Failed to convert ${svgFile}`);
    console.error(`  Make sure svgexport is installed: npm install -g svgexport\n`);
  }
});

console.log('Conversion complete!');
